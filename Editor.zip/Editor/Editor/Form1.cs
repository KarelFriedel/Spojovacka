namespace Editor
{
    public partial class Form1 : Form
    {
        private List<Point> body = new List<Point>();
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point newPoint = new Point(e.X, e.Y);
                body.Add(newPoint);
                this.Invalidate(); 
            }
            else if (e.Button == MouseButtons.Right)
            {
                for (int i = body.Count - 1; i >= 0; i--)
                {
                    int distance = (int)Math.Sqrt(Math.Pow(body[i].X - e.X, 2) + Math.Pow(body[i].Y - e.Y, 2));

                    if (distance < 5) 
                    {
                        body.RemoveAt(i);
                        this.Invalidate(); 
                        break;
                    }
                }
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i < body.Count; i++)
            {
                int size = 10; 
                e.Graphics.FillEllipse(Brushes.Black, body[i].X - size / 2, body[i].Y - size / 2, size, size); 
                e.Graphics.DrawString(i.ToString(), this.Font, Brushes.Black, body[i].X + size / 2, body[i].Y + size / 2); 
            }
        }
    }
}